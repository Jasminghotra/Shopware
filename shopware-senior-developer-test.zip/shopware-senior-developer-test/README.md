# Shopware 6 Developer Test

## 🚀 Schnellstart (< 1 Minute)

### Voraussetzungen
- Docker & Docker Compose
- Mindestens 4GB RAM

### Installation

1. **Shopware 6 starten** (bereits vorinstalliert!):
   ```bash
   docker-compose up -d
   ```

2. **Fertig!** Kein Setup nötig, sofort verfügbar:
   - **Shop**: http://localhost
   - **Admin**: http://localhost/admin
     - User: `admin`
     - Pass: `shopware`
   - **Mailhog**: http://localhost:8025
   - **Adminer**: http://localhost:8888

### Was ist vorinstalliert:
- ✅ Shopware 6 mit Demo-Daten
- ✅ Admin-User bereits angelegt
- ✅ Alle Entwickler-Tools (Composer, Node, etc.)
- ✅ Xdebug für Debugging

## 💻 Entwicklung

### Nach dem ersten Start:
- Alle Shopware-Dateien sind im `shopware/` Ordner
- Plugins entwickeln: `shopware/custom/plugins/`
- Themes entwickeln: `shopware/custom/plugins/`

```bash
# Plugin-Ordner erstellen
mkdir shopware/custom/plugins/MeinPlugin

# Shopware-Befehle ausführen
docker-compose exec web bin/console plugin:refresh
docker-compose exec web bin/console plugin:install --activate MeinPlugin

# Cache leeren
docker-compose exec web bin/console cache:clear
```

## 🎯 Testaufgaben
Siehe `TESTAUFGABEN.md` für alle Aufgaben mit Business-Kontext.

## 🐛 Bei Problemen
```bash
# Container-Logs anzeigen
docker-compose logs -f web

# Alles zurücksetzen
docker-compose down -v
docker-compose up -d
```

**Viel Erfolg!** 🚀