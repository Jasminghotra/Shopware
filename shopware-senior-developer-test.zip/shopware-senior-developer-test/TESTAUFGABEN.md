# Shopware 6 Developer Test - Praxisnahe Aufgaben

## 📋 Überblick
Diese Testaufgaben basieren auf **echten Kundenanforderungen** aus der Praxis. Sie haben **3 Stunden** Zeit und sollen **priorisieren** - lieber eine Aufgabe vollständig als drei halbfertig!

## 🎯 Aufgaben

### Aufgabe 1: Kundenanforderung - Produktbewertungssystem (90 Min)

**Kundenszenario:** 
"Unser Kunde möchte ein eigenes Bewertungssystem, da die Standard-Bewertungen nicht seinen Anforderungen entsprechen. Er benötigt zusätzliche Felder für verifizierte Käufer und Produktvarianten-spezifische Bewertungen."

**Konkrete Anforderungen:**
- Plugin "CustomProductReviews" in `shopware/custom/plugins/` erstellen
- Entity mit folgenden Feldern:
  * `rating` (1-5 Sterne)
  * `title` (max 100 Zeichen)
  * `comment` (Text)
  * `verified_purchase` (bool)
  * `helpful_count` (Anzahl "Hilfreich"-Markierungen)
  
- Admin-Modul mit:
  * Listenansicht mit Filtern (Status, Rating, Verifiziert)
  * Detail-View zum Bearbeiten
  
- API-Endpoint:
  * `POST /store-api/custom-review/create`
  * `GET /store-api/product/{id}/custom-reviews`

**Lieferumfang:**
- [ ] Entity-Definition und Migration
- [ ] Admin-Modul (minimal funktionsfähig)
- [ ] Store-API Route mit Validierung
- [ ] Kurze API-Dokumentation

---

### Aufgabe 2: Performance-Problem - Kategorie-Seiten optimieren (90 Min)

**Kundenszenario:**
"Die Kategorie-Seiten mit 500+ Produkten laden zu langsam (> 3 Sekunden). Der Kunde möchte eine Lazy-Loading-Lösung mit Infinite-Scroll."

**Konkrete Anforderungen:**
- Plugin "CategoryOptimizer" erstellen
- Implementierung:
  * AJAX-Endpoint für Produkt-Nachladung
  * JavaScript für Infinite-Scroll
  * Produkte in 24er-Blöcken laden
  * Loading-Indicator während Nachladung
  
- Performance-Aspekte:
  * Nur benötigte Felder laden (id, name, price, cover)
  * HTTP-Cache-Headers setzen
  * Optimierte Datenbankabfragen

**Lieferumfang:**
- [ ] AJAX-Controller mit Pagination
- [ ] JavaScript für Infinite-Scroll
- [ ] Performance-Optimierungen dokumentieren
- [ ] Cache-Strategie beschreiben

---

### Aufgabe 3: B2B-Feature - Bestellfreigabe-Prozess (60 Min)

**Kundenszenario:**
"B2B-Kunden sollen Bestellungen über 1000€ zur Freigabe an einen Vorgesetzten senden können, bevor sie final bestellt werden."

**Aufgabe: Technisches Konzept erstellen**
- Beschreiben Sie die technische Umsetzung
- Welche Shopware-Komponenten nutzen Sie?
- Datenbank-Schema (Entities)
- Event-Flow (welche Events/Subscriber)
- API-Design für Freigabe-Prozess

**Lieferumfang:**
- [ ] Technisches Konzept (1-2 Seiten)
- [ ] Entity-Definitionen (Code-Skelett)
- [ ] Event-Subscriber-Struktur
- [ ] API-Route-Definitionen

---

## 💡 Bewertungskriterien

### Lösungsansatz (40%)
- Praxistauglichkeit der Lösung
- Shopware-Best-Practices
- Wartbarkeit und Skalierbarkeit
- Verständnis des Business-Kontexts

### Code-Qualität (30%)
- Shopware-Coding-Standards
- Verwendung von Shopware-APIs
- Error-Handling
- Performance-Bewusstsein

### Funktionalität (20%)
- Erfüllung der Anforderungen
- Lauffähiger Code
- Sinnvolle Priorisierung bei Zeitmangel

### Dokumentation (10%)
- Verständliche Erklärungen
- API-Dokumentation
- Installations-Hinweise

---

## 📝 Wichtige Hinweise

### Bei Zeitknappheit
- **Fokus auf Kern-Funktionalität**
- Lieber eine Aufgabe vollständig als drei halbfertig
- **Dokumentieren Sie**, was Sie noch umsetzen würden

### Bei technischen Problemen
- **Dokumentieren Sie das Problem** in einer `PROBLEME.md`
- Zeigen Sie **Lösungsansätze** auf
- Arbeiten Sie an **alternativen Teilaufgaben** weiter

### Plugin-Entwicklung
```bash
# Plugin erstellen (nach dem ersten Start)
mkdir shopware/custom/plugins/MeinPlugin
cd shopware/custom/plugins/MeinPlugin

# Shopware-Commands
docker-compose exec web bin/console plugin:refresh
docker-compose exec web bin/console plugin:install --activate MeinPlugin
```

### Erlaubte Ressourcen
- Shopware-Dokumentation
- Eigene Code-Snippets
- Stack Overflow (mit Quellenangabe)

---

## 🎯 Tipps für den Erfolg

1. **Priorisierung:** Beginnen Sie mit der Aufgabe, die Ihnen am meisten liegt
2. **Zeitmanagement:** Setzen Sie sich Zeitlimits pro Aufgabe
3. **Pragmatismus:** Production-Ready Code ist nicht erwartet, aber saubere Struktur schon
4. **Kommunikation:** Kommentieren Sie unklare Entscheidungen

**Viel Erfolg!** 🚀